

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.DatabaseConnection;
import dao.FoodProduct;
import dao.FoodProductDAO;

/**
 * Servlet implementation class EditProductServlet
 */
@WebServlet("/EditProduct")
public class EditProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditProductServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        FoodProductDAO dao = new FoodProductDAO(DatabaseConnection.getConnection());
        FoodProduct product = dao.findProduct(id);

        request.setAttribute("product", product);
        RequestDispatcher dispatcher = request.getRequestDispatcher("editProduct.jsp");
        dispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        String SKU = request.getParameter("SKU");
        String description = request.getParameter("description");
        String category = request.getParameter("category");
        int price = Integer.parseInt(request.getParameter("price"));

        FoodProduct product = new FoodProduct(id, SKU, description, category, price);
        FoodProductDAO dao = new FoodProductDAO(DatabaseConnection.getConnection());
        dao.updateProduct(product);

        response.sendRedirect("productList.jsp");
    }

}
