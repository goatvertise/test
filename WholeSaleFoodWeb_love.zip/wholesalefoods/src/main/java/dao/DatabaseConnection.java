package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {

    private static final String URL = "jdbc:sqlite:foodstore.db"; // SQLite URL
    private static Connection connection = null;

    // Private constructor to prevent instantiation
    private DatabaseConnection() {
    }

    // Method to get the database connection
    public static Connection getConnection() {
        if (connection == null) {
            try {
                // Load the SQLite JDBC driver (if necessary)
                Class.forName("org.sqlite.JDBC");
                // Establish the database connection
                connection = DriverManager.getConnection(URL);
            } catch (ClassNotFoundException e) {
                System.err.println("SQLite JDBC Driver not found.");
                e.printStackTrace();
            } catch (SQLException e) {
                System.err.println("Connection to SQLite has failed.");
                e.printStackTrace();
            }
        }
        return connection;
    }

    // Method to close the database connection
    public static void closeConnection() {
        if (connection != null) {
            try {
                connection.close();
                connection = null;
            } catch (SQLException e) {
                System.err.println("Error closing the SQLite connection.");
                e.printStackTrace();
            }
        }
    }
}

