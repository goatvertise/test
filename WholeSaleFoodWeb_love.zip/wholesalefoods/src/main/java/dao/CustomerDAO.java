package dao;

import java.sql.*;
import java.util.ArrayList;

public class CustomerDAO {

    private Connection connection;

    // Constructor
    public CustomerDAO(Connection connection) {
        this.connection = connection;
    }

    // findAllCustomers
    public ArrayList<Customer> findAllCustomers() {
        ArrayList<Customer> customers = new ArrayList<>();
        String sql = "SELECT * FROM Customer";

        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Address address = new Address(
                        rs.getString("addressLine1"),
                        rs.getString("addressLine2"),
                        rs.getString("addressLine3"),
                        rs.getString("country"),
                        rs.getString("postCode"));

                Customer customer = new Customer(
                        rs.getInt("customerID"),
                        rs.getString("businessName"),
                        address,
                        rs.getString("telephoneNumber"));

                customers.add(customer);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return customers;
    }

    // findCustomer
    public Customer findCustomer(int customerID) {
        String sql = "SELECT * FROM Customer WHERE customerID = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, customerID);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                Address address = new Address(
                        rs.getString("addressLine1"),
                        rs.getString("addressLine2"),
                        rs.getString("addressLine3"),
                        rs.getString("country"),
                        rs.getString("postCode"));

                return new Customer(
                        rs.getInt("customerID"),
                        rs.getString("businessName"),
                        address,
                        rs.getString("telephoneNumber"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // addCustomer
    public boolean addCustomer(Customer customer) {
        String sql = "INSERT INTO Customer (businessName, addressLine1, addressLine2, addressLine3, country, postCode, telephoneNumber) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, customer.getBusinessName());
            pstmt.setString(2, customer.getAddress().getAddressLine1());
            pstmt.setString(3, customer.getAddress().getAddressLine2());
            pstmt.setString(4, customer.getAddress().getAddressLine3());
            pstmt.setString(5, customer.getAddress().getCountry());
            pstmt.setString(6, customer.getAddress().getPostCode());
            pstmt.setString(7, customer.getTelephoneNumber());

            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // updateCustomer
    public boolean updateCustomer(Customer customer) {
        String sql = "UPDATE Customer SET businessName = ?, addressLine1 = ?, addressLine2 = ?, addressLine3 = ?, country = ?, postCode = ?, telephoneNumber = ? WHERE customerID = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, customer.getBusinessName());
            pstmt.setString(2, customer.getAddress().getAddressLine1());
            pstmt.setString(3, customer.getAddress().getAddressLine2());
            pstmt.setString(4, customer.getAddress().getAddressLine3());
            pstmt.setString(5, customer.getAddress().getCountry());
            pstmt.setString(6, customer.getAddress().getPostCode());
            pstmt.setString(7, customer.getTelephoneNumber());
            pstmt.setInt(8, customer.getCustomerID());

            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // deleteCustomer
    public boolean deleteCustomer(int customerID) {
        String sql = "DELETE FROM Customer WHERE customerID = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, customerID);
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}

