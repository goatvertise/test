package dao;

import java.sql.*;

public class UserDAO {

    private Connection connection;

    // Constructor
    public UserDAO(Connection connection) {
        this.connection = connection;
    }

    // Method for user login
    public User login(String username, String password) { // password should be hashed before calling this method
        String sql = "SELECT * FROM User WHERE username = ? AND password = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, username);
            pstmt.setString(2, password);

            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return new User(
                        rs.getInt("id"),
                        rs.getString("username"),
                        rs.getString("password"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }
}

