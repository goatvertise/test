package dao;

import java.sql.*;
import java.util.ArrayList;

public class FoodProductDAO {

    private Connection connection;

    // Constructor
    public FoodProductDAO(Connection connection) {
        this.connection = connection;
    }

    // findAllProducts
    public ArrayList<FoodProduct> findAllProducts() {
        ArrayList<FoodProduct> products = new ArrayList<>();
        String sql = "SELECT * FROM FoodProduct";

        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                FoodProduct product = new FoodProduct(
                        rs.getInt("id"),
                        rs.getString("SKU"),
                        rs.getString("description"),
                        rs.getString("category"),
                        rs.getInt("price"));
                products.add(product);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return products;
    }

    // findProduct
    public FoodProduct findProduct(int id) {
        String sql = "SELECT * FROM FoodProduct WHERE id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return new FoodProduct(
                        rs.getInt("id"),
                        rs.getString("SKU"),
                        rs.getString("description"),
                        rs.getString("category"),
                        rs.getInt("price"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // deleteProduct
    public boolean deleteProduct(int id) {
        String sql = "DELETE FROM FoodProduct WHERE id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // updateProduct
    public boolean updateProduct(FoodProduct product) {
        String sql = "UPDATE FoodProduct SET SKU = ?, description = ?, category = ?, price = ? WHERE id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, product.getSKU());
            pstmt.setString(2, product.getDescription());
            pstmt.setString(3, product.getCategory());
            pstmt.setInt(4, product.getPrice());
            pstmt.setInt(5, product.getId());

            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // addProduct
    public boolean addProduct(FoodProduct product) {
        String sql = "INSERT INTO FoodProduct (SKU, description, category, price) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, product.getSKU());
            pstmt.setString(2, product.getDescription());
            pstmt.setString(3, product.getCategory());
            pstmt.setInt(4, product.getPrice());

            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}

